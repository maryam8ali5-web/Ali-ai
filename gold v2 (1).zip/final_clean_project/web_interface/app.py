#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
واجهة الويب - نظام التوصيات الحية للذهب
Web Interface - Gold Live Recommendation System
تطوير: MiniMax Agent
"""

import streamlit as st
import sys
import os
import json
from datetime import datetime
import pandas as pd
import plotly.graph_objects as go

# إضافة المسار الرئيسي
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core_systems.weighted_ensemble_live_system import WeightedEnsembleLiveSystem

# إعدادات الصفحة
st.set_page_config(
    page_title="نظام توصيات الذهب الحية",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        color: #FFD700;
        text-shadow: 2px 2px 4px #000000;
        margin-bottom: 2rem;
    }
    .metric-box {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    .buy-signal {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        font-size: 1.5rem;
        text-align: center;
        margin: 1rem 0;
    }
    .sell-signal {
        background: linear-gradient(135deg, #ee0979 0%, #ff6a00 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        font-size: 1.5rem;
        text-align: center;
        margin: 1rem 0;
    }
    .hold-signal {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        font-size: 1.5rem;
        text-align: center;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def create_gauge_chart(confidence, title="مستوى الثقة"):
    """إنشاء مقياس دائري للثقة"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=confidence * 100,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title, 'font': {'size': 24, 'color': 'white'}},
        delta={'reference': 70},
        gauge={
            'axis': {'range': [None, 100], 'tickwidth': 1, 'tickcolor': "white"},
            'bar': {'color': "darkblue"},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 50], 'color': 'rgba(255, 0, 0, 0.3)'},
                {'range': [50, 75], 'color': 'rgba(255, 255, 0, 0.3)'},
                {'range': [75, 100], 'color': 'rgba(0, 255, 0, 0.3)'}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 70
            }
        }
    ))
    
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={'color': "white", 'family': "Arial"},
        height=300
    )
    
    return fig

def main():
    # الشريط الجانبي
    with st.sidebar:
        st.image("https://img.icons8.com/color/96/000000/gold-bars.png", width=100)
        st.title("⚙️ إعدادات النظام")
        
        st.info("**نظام التوصيات الحية للذهب**\n\nيستخدم تقنيات الذكاء الاصطناعي المتقدمة للتنبؤ بحركة أسعار الذهب")
        
        if st.button("🔄 تحديث التوصية", type="primary", use_container_width=True):
            st.session_state.refresh = True
        
        st.markdown("---")
        st.markdown("### 📊 النماذج المستخدمة")
        st.markdown("""
        - ✅ XGBoost
        - ✅ LightGBM  
        - ✅ Random Forest
        - ✅ Stacking Meta Model
        """)
        
        st.markdown("---")
        st.markdown("### 📈 دقة النماذج")
        st.success("**Ensemble System: 77.3%**")
        
        st.markdown("---")
        st.caption("تطوير: MiniMax Agent")
        st.caption(f"آخر تحديث: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    
    # العنوان الرئيسي
    st.markdown('<h1 class="main-header">💰 نظام التوصيات الحية للذهب 💰</h1>', unsafe_allow_html=True)
    
    # زر التحديث في الصفحة الرئيسية
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        if st.button("🚀 الحصول على توصية حية", type="primary", use_container_width=True):
            st.session_state.refresh = True
    
    # تحقق من الحاجة للتحديث
    if 'refresh' not in st.session_state:
        st.session_state.refresh = False
    
    if st.session_state.refresh or 'recommendation' not in st.session_state:
        with st.spinner('🔄 جاري جلب البيانات الحية وتحليلها...'):
            try:
                system = WeightedEnsembleLiveSystem()
                recommendation = system.run_live_system()
                st.session_state.recommendation = recommendation
                st.session_state.refresh = False
                st.success("✅ تم تحديث التوصية بنجاح!")
            except Exception as e:
                st.error(f"❌ خطأ: {e}")
                return
    
    if 'recommendation' in st.session_state and st.session_state.recommendation:
        rec = st.session_state.recommendation
        final_rec = rec['final_recommendation']
        
        # عرض التوصية الرئيسية
        action = final_rec['action']
        if action == "BUY":
            st.markdown(f'<div class="buy-signal">📈 توصية: شراء BUY</div>', unsafe_allow_html=True)
        elif action == "SELL":
            st.markdown(f'<div class="sell-signal">📉 توصية: بيع SELL</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="hold-signal">⏸️ توصية: انتظار HOLD</div>', unsafe_allow_html=True)
        
        # الصف الأول: المعلومات الأساسية
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="💰 السعر الحالي",
                value=f"${rec['current_price']:.2f}",
                delta=None
            )
        
        with col2:
            confidence_pct = final_rec['confidence'] * 100
            st.metric(
                label="📊 مستوى الثقة",
                value=f"{confidence_pct:.1f}%",
                delta=None
            )
        
        with col3:
            st.metric(
                label="🔻 وقف الخسارة",
                value=f"${final_rec['stop_loss']:.2f}",
                delta=f"{final_rec['stop_loss'] - rec['current_price']:.2f}"
            )
        
        with col4:
            st.metric(
                label="🔺 جني الأرباح",
                value=f"${final_rec['take_profit']:.2f}",
                delta=f"+{final_rec['take_profit'] - rec['current_price']:.2f}"
            )
        
        # الصف الثاني: مقياس الثقة والمعلومات التفصيلية
        col1, col2 = st.columns(2)
        
        with col1:
            # مقياس الثقة
            fig = create_gauge_chart(final_rec['confidence'])
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # معلومات إضافية
            st.markdown("### 📊 تفاصيل التوصية")
            
            info_data = {
                "الرمز": rec['symbol'],
                "التوصية": final_rec['action'],
                "مستوى الثقة": f"{final_rec['confidence']:.1%}",
                "ATR (14)": f"{final_rec['atr_value']:.2f}",
                "مضاعف ATR": f"{final_rec['atr_multiplier']:.2f}",
                "مسافة الوقف": f"{final_rec['stop_distance']:.2f}",
                "الوقت": rec['timestamp'].split('T')[1].split('.')[0]
            }
            
            for key, value in info_data.items():
                st.markdown(f"**{key}:** {value}")
        
        # قسم المؤشرات الفنية
        st.markdown("---")
        st.markdown("### 📈 المؤشرات الفنية")
        
        col1, col2, col3, col4 = st.columns(4)
        
        indicators = rec['market_indicators']
        
        with col1:
            rsi_value = indicators['rsi']
            rsi_color = "🟢" if 30 < rsi_value < 70 else "🔴"
            st.metric(
                label=f"{rsi_color} RSI",
                value=f"{rsi_value:.1f}",
                delta="Normal" if 30 < rsi_value < 70 else "Extreme"
            )
        
        with col2:
            bb_pos = indicators['bb_position']
            st.metric(
                label="📊 Bollinger Position",
                value=f"{bb_pos:.2f}",
                delta=None
            )
        
        with col3:
            st.metric(
                label="📉 حالة السوق",
                value=indicators['market_condition'],
                delta=None
            )
        
        with col4:
            st.metric(
                label="📊 ATR (14)",
                value=f"{indicators['atr_14']:.2f}",
                delta=None
            )
        
        # قسم مقارنة النماذج
        st.markdown("---")
        st.markdown("### 🧠 مقارنة النماذج")
        
        models_comparison = rec['model_comparison']
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Weighted Ensemble")
            we_data = models_comparison['weighted_ensemble']
            st.markdown(f"**التوصية:** {we_data['action']}")
            st.progress(we_data['confidence'])
            st.caption(f"الثقة: {we_data['confidence']:.1%}")
        
        with col2:
            st.markdown("#### Stacking Meta Model")
            sm_data = models_comparison['stacking_meta']
            st.markdown(f"**التوصية:** {sm_data['action']}")
            st.progress(sm_data['confidence'])
            st.caption(f"الثقة: {sm_data['confidence']:.1%}")
        
        # قسم النماذج الفردية
        st.markdown("---")
        st.markdown("### ⚖️ النماذج الفردية وأوزانها")
        
        individual_models = rec['individual_models']
        weights = rec['model_weights']
        
        models_df = pd.DataFrame({
            'النموذج': ['XGBoost', 'LightGBM', 'Random Forest'],
            'التنبؤ': [
                'شراء' if individual_models['xgboost'] == 2 else ('بيع' if individual_models['xgboost'] == 0 else 'انتظار'),
                'شراء' if individual_models['lightgbm'] == 2 else ('بيع' if individual_models['lightgbm'] == 0 else 'انتظار'),
                'شراء' if individual_models['randomforest'] == 2 else ('بيع' if individual_models['randomforest'] == 0 else 'انتظار')
            ],
            'الوزن': [
                f"{weights['xgboost']:.1%}",
                f"{weights['lightgbm']:.1%}",
                f"{weights['randomforest']:.1%}"
            ]
        })
        
        st.dataframe(models_df, use_container_width=True, hide_index=True)
        
        # زر تحميل التقرير
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            json_str = json.dumps(rec, indent=2, ensure_ascii=False)
            st.download_button(
                label="📥 تحميل التقرير الكامل (JSON)",
                data=json_str,
                file_name=f"gold_recommendation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json",
                use_container_width=True
            )

if __name__ == "__main__":
    main()