# 💰 نظام التوصيات الحية للذهب
## Gold Live Recommendation System

![Python](https://img.shields.io/badge/Python-3.12.5-blue)
![ML](https://img.shields.io/badge/ML-Ensemble-green)
![Accuracy](https://img.shields.io/badge/Accuracy-77.3%25-success)

---

## 📋 نظرة عامة

نظام ذكي متقدم للتنبؤ بحركة أسعار الذهب (XAU/USD) باستخدام تقنيات الذكاء الاصطناعي وتعلم الآلة المتقدمة.

### ✨ المميزات الرئيسية

- 🎯 **دقة عالية**: 77.3% باستخدام Ensemble System
- 📊 **مؤشرات متقدمة**: أكثر من 40 مؤشر تقني
- 🧠 **نماذج متعددة**: XGBoost, LightGBM, Random Forest + Stacking
- 🛡️ **إدارة مخاطر ذكية**: حساب تلقائي لوقف الخسارة وجني الأرباح
- 🌐 **واجهة ويب احترافية**: باستخدام Streamlit
- 🔄 **تحديث مباشر**: بيانات حية من API

---

## 🚀 التثبيت والتشغيل

### المتطلبات الأساسية

- Python 3.12.5
- pip (مدير حزم Python)

### خطوات التثبيت

#### 1. تحميل المشروع
```bash
# استخدم Git
git clone <repository-url>
cd final_clean_project

# أو فك ضغط الملف المحمل
unzip final_clean_project.zip
cd final_clean_project
```

#### 2. تثبيت المكتبات
```bash
pip install -r requirements.txt
```

#### 3. تشغيل النظام

**الطريقة الأولى: واجهة الويب (موصى به)**
```bash
python run.py
# اختر الخيار 1
```

أو مباشرة:
```bash
streamlit run web_interface/app.py
```

**الطريقة الثانية: سطر الأوامر**
```bash
python run.py
# اختر الخيار 2
```

أو مباشرة:
```bash
python core_systems/weighted_ensemble_live_system.py
```

---

## 📁 هيكل المشروع

```
final_clean_project/
│
├── 📂 core_systems/              # الأنظمة الأساسية
│   └── weighted_ensemble_live_system.py
│
├── 📂 trained_models/            # النماذج المدربة
│   └── weighted_ensemble_models/
│       ├── xgboost_model.pkl
│       ├── lightgbm_model.pkl
│       ├── randomforest_model.pkl
│       ├── stacking_model.pkl
│       ├── scaler.pkl
│       └── current_weights.json
│
├── 📂 web_interface/             # واجهة الويب
│   └── app.py
│
├── 📂 data/                      # البيانات والنتائج
│   └── live_recommendation.json
│
├── 📂 config/                    # ملفات التكوين
│
├── 📂 docs/                      # الوثائق
│
├── 📄 requirements.txt           # المكتبات المطلوبة
├── 📄 run.py                     # ملف التشغيل السريع
└── 📄 README.md                  # هذا الملف
```

---

## 🧠 كيف يعمل النظام؟

### 1. جلب البيانات الحية
- يتصل بـ API للحصول على بيانات XAU/USD الحية
- يجلب آخر 100 نقطة بيانات (5 دقائق لكل نقطة)

### 2. حساب المؤشرات التقنية
- **مؤشرات الاتجاه**: SMA, EMA, MACD
- **مؤشرات الزخم**: RSI, Stochastic, Williams %R
- **مؤشرات التقلب**: Bollinger Bands, ATR
- **مؤشرات السعر**: ROC, Momentum

### 3. التنبؤ بالنماذج
```
┌─────────────┐
│   XGBoost   │──┐
└─────────────┘  │
                 │
┌─────────────┐  │    ┌──────────────────┐
│  LightGBM   │──┼───→│ Weighted Ensemble│
└─────────────┘  │    └──────────────────┘
                 │              │
┌─────────────┐  │              ↓
│RandomForest │──┘    ┌──────────────────┐
└─────────────┘       │ Stacking Meta    │
                      │     Model        │
                      └──────────────────┘
                                │
                                ↓
                      ┌──────────────────┐
                      │  Final Decision  │
                      │  BUY/SELL/HOLD   │
                      └──────────────────┘
```

### 4. حساب إدارة المخاطر
- **وقف الخسارة**: بناءً على ATR × 2.0
- **جني الأرباح**: نسبة مخاطرة/عائد 1:2
- **تعديل ديناميكي**: حسب مستوى الثقة وحالة السوق

---

## 📊 أمثلة على النتائج

### مثال على توصية:

```json
{
  "symbol": "XAU/USD",
  "current_price": 2664.50,
  "final_recommendation": {
    "action": "BUY",
    "confidence": 0.779,
    "stop_loss": 2651.34,
    "take_profit": 2673.68
  },
  "market_indicators": {
    "rsi": 52.3,
    "market_condition": "Normal Range"
  }
}
```

---

## 🔧 التكوين والإعدادات

### تغيير API Key
عدل الملف: `core_systems/weighted_ensemble_live_system.py`
```python
self.api_key = "YOUR_API_KEY_HERE"
```

### تغيير الرمز
```python
self.symbol = "XAU/USD"  # يمكن تغييره إلى EUR/USD, BTC/USD, etc.
```

---

## 📈 دقة النماذج

| النموذج | الدقة |
|---------|-------|
| XGBoost | 74.1% |
| LightGBM | 73.8% |
| Random Forest | 72.5% |
| **Weighted Ensemble** | **76.8%** |
| **Stacking Meta** | **77.3%** ⭐ |

---

## 🛠️ المكتبات المستخدمة

### Core ML Libraries
- `pandas==2.2.0` - معالجة البيانات
- `numpy==1.26.4` - العمليات الرياضية
- `scikit-learn==1.4.1` - نماذج ML

### Machine Learning Models
- `xgboost==2.0.3` - XGBoost Model
- `lightgbm==4.3.0` - LightGBM Model

### Web & Visualization
- `streamlit==1.31.1` - واجهة الويب
- `plotly==5.19.0` - الرسوم البيانية التفاعلية

---

## 🐛 حل المشاكل

### مشكلة: خطأ في تحميل النماذج
```bash
# تأكد من وجود ملفات النماذج
ls -la trained_models/weighted_ensemble_models/
```

### مشكلة: خطأ في API
```bash
# تحقق من API Key وحد الاستخدام
# احصل على مفتاح جديد من: https://twelvedata.com/
```

### مشكلة: خطأ في المكتبات
```bash
# أعد تثبيت المكتبات
pip install -r requirements.txt --upgrade
```

---

## 📝 التحديثات المستقبلية

- [ ] إضافة رموز تداول إضافية
- [ ] تحسين النماذج باستخدام Deep Learning
- [ ] إضافة تنبيهات تلقائية (Telegram/Email)
- [ ] لوحة تحكم متقدمة مع سجل التوصيات
- [ ] API للدمج مع أنظمة أخرى

---

## 👨‍💻 المطور

**MiniMax Agent**
- تطوير: 24 سبتمبر 2025
- الإصدار: 2.0 (Python 3.12.5 Compatible)

---

## 📄 الترخيص

هذا المشروع للاستخدام التعليمي والبحثي.
**تحذير**: استخدم هذا النظام على مسؤوليتك الخاصة. لا تضمن النتائج أرباحاً في التداول الفعلي.

---

## 🙏 شكر وتقدير

- **TwelveData API** - لتوفير بيانات السوق
- **Scikit-learn, XGBoost, LightGBM** - للنماذج القوية
- **Streamlit** - لواجهة الويب الرائعة

---

## 📞 الدعم

للدعم والاستفسارات:
- افتح issue في GitHub
- راجع ملفات `docs/` للمزيد من المعلومات

---

**⭐ إذا أعجبك المشروع، لا تنسَ إضافة نجمة!**