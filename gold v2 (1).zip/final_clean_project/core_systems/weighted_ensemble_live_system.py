#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
نظام التوصيات الحية - Weighted Ensemble
تطوير: MiniMax Agent
التاريخ: 24 سبتمبر 2025
Python 3.12.5 Compatible
"""

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import pickle
import json
import requests
from datetime import datetime
import os


class WeightedEnsembleLiveSystem:
    def __init__(self):
        """تهيئة نظام التوصيات الحية"""
        print("🚀 تهيئة نظام التوصيات الحية - Weighted Ensemble...")
        print("⚡ مع Stacking Meta Model المتطور")
        print("="*60)
        
        self.api_key = "c2ad41fddc534befa2f9dd60250b9e2c"
        self.symbol = "XAU/USD"
        self.models_dir = "trained_models/weighted_ensemble_models"
        
        # تحميل النماذج والمعاملات
        self.load_models()
        
        print("✅ تم تهيئة النظام الحي بنجاح")

    def load_models(self):
        """تحميل النماذج المحفوظة"""
        print("📂 تحميل النماذج المحفوظة...")
        
        try:
            # تحميل النماذج الفردية
            with open(f"{self.models_dir}/xgboost_model.pkl", 'rb') as f:
                self.xgboost_model = pickle.load(f)
            
            with open(f"{self.models_dir}/lightgbm_model.pkl", 'rb') as f:
                self.lightgbm_model = pickle.load(f)
            
            with open(f"{self.models_dir}/randomforest_model.pkl", 'rb') as f:
                self.randomforest_model = pickle.load(f)
            
            # تحميل Stacking Model
            with open(f"{self.models_dir}/stacking_model.pkl", 'rb') as f:
                self.stacking_model = pickle.load(f)
            
            # تحميل المعاملات
            with open(f"{self.models_dir}/scaler.pkl", 'rb') as f:
                self.scaler = pickle.load(f)
            
            # تحميل الأوزان
            with open(f"{self.models_dir}/current_weights.json", 'r') as f:
                self.weights = json.load(f)
            
            print("   ✅ XGBoost Model")
            print("   ✅ LightGBM Model")
            print("   ✅ RandomForest Model")
            print("   ✅ Stacking Meta Model")
            print("   ✅ Scaler & Weights")
            
        except Exception as e:
            print(f"❌ خطأ في تحميل النماذج: {e}")
            raise

    def fetch_live_data(self):
        """جلب البيانات الحية"""
        print("📊 جلب البيانات الحية...")
        
        url = f"https://api.twelvedata.com/time_series"
        params = {
            'symbol': self.symbol,
            'interval': '5min',
            'outputsize': 100,
            'apikey': self.api_key,
            'format': 'JSON'
        }
        
        try:
            response = requests.get(url, params=params, timeout=30)
            data = response.json()
            
            if 'values' not in data:
                print(f"❌ خطأ في البيانات: {data}")
                return None
            
            df = pd.DataFrame(data['values'])
            df['datetime'] = pd.to_datetime(df['datetime'])
            df = df.sort_values('datetime').reset_index(drop=True)
            
            # تحويل الأعمدة لرقمية
            numeric_columns = ['open', 'high', 'low', 'close']
            if 'volume' in df.columns:
                numeric_columns.append('volume')
            else:
                df['volume'] = 1000000
                numeric_columns.append('volume')
            
            for col in numeric_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            print(f"✅ تم جلب {len(df)} نقطة بيانات حية")
            return df
            
        except Exception as e:
            print(f"❌ خطأ في جلب البيانات الحية: {e}")
            return None

    def create_live_features(self, df):
        """إنشاء المؤشرات للبيانات الحية"""
        print("🔧 حساب المؤشرات الحية...")
        
        df_features = df.copy()
        
        try:
            # Basic indicators
            df_features['sma_20'] = df_features['close'].rolling(20).mean()
            df_features['sma_50'] = df_features['close'].rolling(50).mean()
            df_features['ema_12'] = df_features['close'].ewm(span=12).mean()
            df_features['ema_26'] = df_features['close'].ewm(span=26).mean()
            
            # MACD calculation
            ema_12 = df_features['close'].ewm(span=12).mean()
            ema_26 = df_features['close'].ewm(span=26).mean()
            df_features['macd'] = ema_12 - ema_26
            df_features['macd_signal'] = df_features['macd'].ewm(span=9).mean()
            df_features['macd_histogram'] = df_features['macd'] - df_features['macd_signal']
            
            # RSI calculation
            delta = df_features['close'].diff()
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(14).mean()
            avg_loss = loss.rolling(14).mean()
            rs = avg_gain / avg_loss
            df_features['rsi'] = 100 - (100 / (1 + rs))
            
            # Bollinger Bands calculation
            sma_20 = df_features['close'].rolling(20).mean()
            std_20 = df_features['close'].rolling(20).std()
            df_features['bb_upper'] = sma_20 + (std_20 * 2)
            df_features['bb_middle'] = sma_20
            df_features['bb_lower'] = sma_20 - (std_20 * 2)
            df_features['bb_width'] = df_features['bb_upper'] - df_features['bb_lower']
            df_features['bb_position'] = (df_features['close'] - df_features['bb_lower']) / (df_features['bb_upper'] - df_features['bb_lower'])
            
            # ATR calculation
            high_low = df_features['high'] - df_features['low']
            high_close = np.abs(df_features['high'] - df_features['close'].shift())
            low_close = np.abs(df_features['low'] - df_features['close'].shift())
            true_range = np.maximum(high_low, np.maximum(high_close, low_close))
            df_features['atr_14'] = true_range.rolling(14).mean()
            df_features['atr_7'] = true_range.rolling(7).mean()
            df_features['atr_21'] = true_range.rolling(21).mean()
            
            # Stochastic calculation
            low_14 = df_features['low'].rolling(14).min()
            high_14 = df_features['high'].rolling(14).max()
            df_features['stoch_k'] = 100 * ((df_features['close'] - low_14) / (high_14 - low_14))
            df_features['stoch_d'] = df_features['stoch_k'].rolling(3).mean()
            
            # Williams %R
            df_features['williams_r'] = -100 * ((high_14 - df_features['close']) / (high_14 - low_14))
            
            # Volume indicators
            df_features['volume_sma'] = df_features['volume'].rolling(20).mean()
            df_features['volume_ratio'] = df_features['volume'] / df_features['volume_sma']
            
            # Price action features
            df_features['price_change'] = df_features['close'].pct_change()
            df_features['high_low_ratio'] = df_features['high'] / df_features['low']
            df_features['close_open_ratio'] = df_features['close'] / df_features['open']
            
            # Lag features
            for lag in [1, 2, 3, 5]:
                df_features[f'close_lag_{lag}'] = df_features['close'].shift(lag)
                df_features[f'volume_lag_{lag}'] = df_features['volume'].shift(lag)
                df_features[f'price_change_lag_{lag}'] = df_features['price_change'].shift(lag)
            
            # Rolling statistics
            for window in [5, 10, 20]:
                df_features[f'close_std_{window}'] = df_features['close'].rolling(window).std()
                df_features[f'volume_std_{window}'] = df_features['volume'].rolling(window).std()
                df_features[f'price_change_std_{window}'] = df_features['price_change'].rolling(window).std()
            
            # Additional technical indicators
            df_features['momentum'] = df_features['close'] - df_features['close'].shift(10)
            df_features['roc'] = df_features['close'].pct_change(periods=10) * 100
            
            # Price position relative to recent highs/lows
            df_features['high_20'] = df_features['high'].rolling(20).max()
            df_features['low_20'] = df_features['low'].rolling(20).min()
            df_features['price_position'] = (df_features['close'] - df_features['low_20']) / (df_features['high_20'] - df_features['low_20'])
            
            print("✅ تم حساب جميع المؤشرات الحية")
            return df_features
            
        except Exception as e:
            print(f"⚠️ خطأ في حساب المؤشرات: {e}")
            return df

    def prepare_live_data(self, df):
        """تحضير البيانات للتنبؤ - Python 3.12.5 Compatible"""
        feature_columns = [col for col in df.columns 
                          if col not in ['datetime', 'open', 'high', 'low', 'close', 'volume']]
        
        current_data = df[feature_columns].iloc[-1:].copy()
        
        # Python 3.12.5 Compatible: استخدام bfill() و ffill() بدلاً من fillna(method=...)
        current_data = current_data.bfill().ffill().fillna(0)
        
        # تطبيق التطبيع
        current_data_scaled = self.scaler.transform(current_data)
        current_data_scaled = pd.DataFrame(current_data_scaled, columns=feature_columns)
        
        return current_data_scaled

    def weighted_ensemble_predict(self, X):
        """التنبؤ باستخدام Weighted Ensemble"""
        xgb_pred = self.xgboost_model.predict(X)[0]
        xgb_proba = self.xgboost_model.predict_proba(X)[0]
        
        lgb_pred = self.lightgbm_model.predict(X)[0]
        lgb_proba = self.lightgbm_model.predict_proba(X)[0]
        
        rf_pred = self.randomforest_model.predict(X)[0]
        rf_proba = self.randomforest_model.predict_proba(X)[0]
        
        weighted_proba = (
            self.weights['xgboost'] * xgb_proba +
            self.weights['lightgbm'] * lgb_proba +
            self.weights['randomforest'] * rf_proba
        )
        
        weighted_pred = np.argmax(weighted_proba)
        confidence = np.max(weighted_proba)
        
        return {
            'weighted_prediction': weighted_pred,
            'weighted_confidence': confidence,
            'individual_predictions': {
                'xgboost': int(xgb_pred),
                'lightgbm': int(lgb_pred),
                'randomforest': int(rf_pred)
            },
            'individual_confidences': {
                'xgboost': float(np.max(xgb_proba)),
                'lightgbm': float(np.max(lgb_proba)),
                'randomforest': float(np.max(rf_proba))
            }
        }

    def stacking_predict(self, X):
        """التنبؤ باستخدام Stacking Meta Model"""
        stacking_pred = self.stacking_model.predict(X)[0]
        stacking_proba = self.stacking_model.predict_proba(X)[0]
        stacking_confidence = np.max(stacking_proba)
        
        return {
            'stacking_prediction': int(stacking_pred),
            'stacking_confidence': float(stacking_confidence)
        }

    def calculate_dynamic_risk(self, current_price, atr_value, prediction, confidence, market_condition):
        """حساب إدارة المخاطر الديناميكية المحسنة"""
        base_atr_multiplier = 2.0
        
        # تعديل بناءً على حالة السوق
        if market_condition in ["Overbought", "Oversold"]:
            atr_multiplier = base_atr_multiplier * 1.2
        else:
            atr_multiplier = base_atr_multiplier
        
        # تعديل بناءً على مستوى الثقة
        if confidence > 0.75:
            atr_multiplier *= 1.1
        elif confidence < 0.6:
            atr_multiplier *= 0.8
        
        stop_distance = atr_value * atr_multiplier
        take_profit_distance = stop_distance * 2.0
        
        if prediction == 2:  # Buy
            stop_loss = current_price - stop_distance
            take_profit = current_price + take_profit_distance
            action = "BUY"
        elif prediction == 0:  # Sell
            stop_loss = current_price + stop_distance
            take_profit = current_price - take_profit_distance
            action = "SELL"
        else:  # Hold
            support_level = current_price - (stop_distance * 0.5)
            resistance_level = current_price + (stop_distance * 0.5)
            stop_loss = support_level
            take_profit = resistance_level
            action = "HOLD"
        
        return {
            'action': action,
            'stop_loss': round(stop_loss, 2),
            'take_profit': round(take_profit, 2),
            'stop_distance': round(stop_distance, 2),
            'atr_multiplier': round(atr_multiplier, 2)
        }

    def generate_live_recommendation(self):
        """إنشاء توصية حية شاملة"""
        print("🎯 إنشاء التوصية الحية الشاملة...")
        print("="*50)
        
        df = self.fetch_live_data()
        if df is None:
            return None
        
        df_features = self.create_live_features(df)
        X_current = self.prepare_live_data(df_features)
        
        weighted_results = self.weighted_ensemble_predict(X_current)
        stacking_results = self.stacking_predict(X_current)
        
        current_price = df['close'].iloc[-1]
        current_atr = df_features['atr_14'].iloc[-1]
        
        final_prediction = stacking_results['stacking_prediction']
        final_confidence = stacking_results['stacking_confidence']
        
        # تحديد حالة السوق
        rsi = df_features['rsi'].iloc[-1]
        bb_position = df_features['bb_position'].iloc[-1]
        
        if rsi > 70:
            market_condition = "Overbought"
        elif rsi < 30:
            market_condition = "Oversold"
        elif bb_position > 0.8:
            market_condition = "Near Upper Band"
        elif bb_position < 0.2:
            market_condition = "Near Lower Band"
        else:
            market_condition = "Normal Range"
        
        risk_management = self.calculate_dynamic_risk(
            current_price, current_atr, final_prediction, final_confidence, market_condition
        )
        
        recommendation = {
            'timestamp': datetime.now().isoformat(),
            'symbol': self.symbol,
            'current_price': float(current_price),
            'final_recommendation': {
                'action': risk_management['action'],
                'confidence': final_confidence,
                'stop_loss': risk_management['stop_loss'],
                'take_profit': risk_management['take_profit'],
                'stop_distance': risk_management['stop_distance'],
                'atr_value': float(current_atr),
                'atr_multiplier': risk_management['atr_multiplier']
            },
            'model_comparison': {
                'weighted_ensemble': {
                    'prediction': weighted_results['weighted_prediction'],
                    'confidence': weighted_results['weighted_confidence'],
                    'action': self.get_action_name(weighted_results['weighted_prediction'])
                },
                'stacking_meta': {
                    'prediction': stacking_results['stacking_prediction'],
                    'confidence': stacking_results['stacking_confidence'],
                    'action': self.get_action_name(stacking_results['stacking_prediction'])
                }
            },
            'individual_models': weighted_results['individual_predictions'],
            'model_weights': self.weights,
            'market_indicators': {
                'rsi': float(rsi),
                'bb_position': float(bb_position),
                'atr_14': float(current_atr),
                'market_condition': market_condition
            }
        }
        
        return recommendation

    def get_action_name(self, prediction):
        """تحويل رقم التنبؤ إلى اسم الإجراء"""
        actions = {0: "SELL", 1: "HOLD", 2: "BUY"}
        return actions.get(prediction, "HOLD")

    def display_recommendation(self, recommendation):
        """عرض التوصية بطريقة منسقة"""
        if recommendation is None:
            print("❌ لم يتم إنشاء توصية")
            return
        
        print("\n🎯 التوصية الحية - Weighted Ensemble System:")
        print("="*60)
        
        final_rec = recommendation['final_recommendation']
        
        print(f"📊 الرمز: {recommendation['symbol']}")
        print(f"💰 السعر الحالي: ${recommendation['current_price']:.2f}")
        print(f"🎯 التوصية: {final_rec['action']}")
        print(f"📈 مستوى الثقة: {final_rec['confidence']:.1%}")
        print(f"🔻 وقف الخسارة: ${final_rec['stop_loss']:.2f}")
        print(f"🔺 جني الأرباح: ${final_rec['take_profit']:.2f}")
        print(f"📊 ATR: {final_rec['atr_value']:.2f}")
        
        print(f"\n🧠 مقارنة النماذج:")
        models = recommendation['model_comparison']
        print(f"   Weighted Ensemble: {models['weighted_ensemble']['action']} ({models['weighted_ensemble']['confidence']:.1%})")
        print(f"   Stacking Meta: {models['stacking_meta']['action']} ({models['stacking_meta']['confidence']:.1%})")
        
        print(f"\n📊 مؤشرات السوق:")
        indicators = recommendation['market_indicators']
        print(f"   RSI: {indicators['rsi']:.1f}")
        print(f"   BB Position: {indicators['bb_position']:.2f}")
        print(f"   حالة السوق: {indicators['market_condition']}")

    def save_recommendation(self, recommendation, filename="data/live_recommendation.json"):
        """حفظ التوصية في ملف"""
        if recommendation:
            def convert_to_serializable(obj):
                if isinstance(obj, np.integer):
                    return int(obj)
                elif isinstance(obj, np.floating):
                    return float(obj)
                elif isinstance(obj, np.ndarray):
                    return obj.tolist()
                elif isinstance(obj, dict):
                    return {key: convert_to_serializable(value) for key, value in obj.items()}
                elif isinstance(obj, list):
                    return [convert_to_serializable(item) for item in obj]
                else:
                    return obj
            
            serializable_recommendation = convert_to_serializable(recommendation)
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(serializable_recommendation, f, indent=2, ensure_ascii=False)
            print(f"\n💾 تم حفظ التوصية: {filename}")

    def run_live_system(self):
        """تشغيل النظام الحي الكامل"""
        try:
            recommendation = self.generate_live_recommendation()
            self.display_recommendation(recommendation)
            self.save_recommendation(recommendation)
            return recommendation
        except Exception as e:
            print(f"❌ خطأ في تشغيل النظام الحي: {e}")
            import traceback
            traceback.print_exc()
            return None


if __name__ == "__main__":
    print("🚀 تشغيل نظام التوصيات الحية - Weighted Ensemble")
    print("="*70)
    
    system = WeightedEnsembleLiveSystem()
    recommendation = system.run_live_system()
    
    print("\n" + "="*70)
    print("🎉 اكتمل نظام التوصيات الحية!")
    print("="*70)