#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تشغيل سريع - نظام التوصيات الحية للذهب
Quick Start - Gold Live Recommendation System
"""

import subprocess
import sys
import os

def main():
    """تشغيل النظام"""
    print("="*70)
    print("🚀 نظام التوصيات الحية للذهب - Gold Live Recommendation System")
    print("="*70)
    print()
    
    print("اختر طريقة التشغيل:")
    print()
    print("1️⃣  واجهة الويب (Streamlit) - موصى به")
    print("2️⃣  واجهة سطر الأوامر (CLI)")
    print("3️⃣  الخروج")
    print()
    
    choice = input("اختيارك (1-3): ").strip()
    
    if choice == "1":
        print("\n🌐 تشغيل واجهة الويب...")
        print("سيتم فتح المتصفح تلقائياً على: http://localhost:8501")
        print("اضغط Ctrl+C للإيقاف")
        print("-"*70)
        
        # تشغيل Streamlit
        subprocess.run([
            sys.executable, "-m", "streamlit", "run",
            "web_interface/app.py",
            "--server.port=8501",
            "--server.headless=true"
        ])
    
    elif choice == "2":
        print("\n💻 تشغيل واجهة سطر الأوامر...")
        print("-"*70)
        
        # تشغيل CLI
        subprocess.run([
            sys.executable,
            "core_systems/weighted_ensemble_live_system.py"
        ])
    
    elif choice == "3":
        print("\n👋 شكراً لاستخدام النظام!")
        sys.exit(0)
    
    else:
        print("\n❌ اختيار غير صحيح!")
        sys.exit(1)

if __name__ == "__main__":
    main()